//package edu.cscc;
import java.util.*; //Scanner
import java.lang.Math;

// Joseph Schopick
// This program prompts a user to input the radius of a circle and computes the circle�s area and perimeter.
public class SchopickLab5
{
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args)
    {
		//Declatations go here
		double vRadius, vArea, vPerimeter;

    	//Input
    	System.out.print("Enter the radius of your circle: ");
    	vRadius = input.nextDouble();

    	//Computation
    	vArea = Math.PI * Math.pow(vRadius,2);
    	vPerimeter = 2 * Math.PI * vRadius;

    	//Output statements
    	System.out.println("The area of a circle with a radius of "+vRadius+" is "+vArea);
    	System.out.println("The perimeter of a circle with a radius of "+vRadius+" is "+vPerimeter);
    }
}
