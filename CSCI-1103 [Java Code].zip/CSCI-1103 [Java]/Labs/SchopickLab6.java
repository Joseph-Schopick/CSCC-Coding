import java.util.*; //Scanner

// Joseph Schopick
// This program prompts a user for the cost of a product and then prompts the user for one of three shipping options.The program then prints the cost of the product, the cost of shipping, and the total cost.
public class SchopickLab6
{
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args)
    {
		//Declatations go here
		int vShippingType;
		double vShippingCost, vProductCost, vTotalCost;

    	//Input
    	System.out.print("Enter the cost of the product ordered: ");
    	vProductCost = input.nextDouble();

    	//Output shipping types
    	System.out.println("Standard shipping (enter '1') for $7.95");
    	System.out.println("Express shipping (enter '2') for $13.95");
    	System.out.println("Priority shipping (enter '3') for $23.95");

    	//Input
    	System.out.print("Enter your choice (1, 2 or 3): ");
    	vShippingType = input.nextInt();

    	//Computation
    	if(vShippingType == 1)
    	{
			vShippingCost = 7.95;
		}
		else if(vShippingType == 2)
    	{
			vShippingCost = 13.95;
		}
		else //if(vShippingType == 3)
    	{
			vShippingCost = 23.95;
		}
    	vTotalCost = vProductCost + vShippingCost;

    	//Output statements
    	System.out.println("The cost of the product is "+vProductCost+" plus shipping of "+vShippingCost+" equals "+vTotalCost);
    }
}
