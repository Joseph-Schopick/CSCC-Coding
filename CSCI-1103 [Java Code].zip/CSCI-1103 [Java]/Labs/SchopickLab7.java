import java.util.Scanner;

// Joseph Schopick
// This program prompts a user to input products and their costs. The program looks for items that cost over $100.00 and finds the average cost of those items.
public class SchopickLab7
{
    private static Scanner input = new Scanner(System.in);

    public static void main(String[] args)
    {
		//Declatations go here
		String vProductName;
		int vCount = 0;
		double vProductCost, vAverage;
		double vTotal = 0;

    	//Input the product or keep the loop from running
    	System.out.print("Enter the product ordered - type 'stop' to end: ");
    	vProductName = input.nextLine();

    	//Loop input until input is 'stop'
    	while (!vProductName.equals("stop"))
    	{
    		//Input cost
    		System.out.print("Enter the cost of the product ordered: ");
    		vProductCost = input.nextDouble();
    		input.nextLine();
    		//if the product costs more than $100.00 alter the vCount and vTotal variables
    		if (vProductCost >= 100.00)
    		{
				vCount += 1;
				vTotal += vProductCost;
			}
			//Input the product or end the loop
			System.out.print("Enter the product ordered - type 'stop' to end: ");
    		vProductName = input.nextLine();
		}

		//Calculate the average cost of the items greater than or less than $100.00
		vAverage = vTotal/vCount;

    	//Output the number of items and the average cost
    	System.out.println("There were "+vCount+" item(s) that had a cost of $100.00 or more");
		System.out.println("The average price of items with a cost of $100.00 or more is $"+vAverage);
    }
}
