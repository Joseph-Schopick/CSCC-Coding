
// Joseph Schopick
// This program print out the first fifteen numbers of the Fibonacci sequence using a loop.
public class SchopickLab8
{
    public static void main(String[] args)
    {
		//Declatations go here
		long vPrevious, vCurrent=0, vNext=1;

    	//Loop until the first fifteen numbers have been printed
    	for (int x = 0; x < 15; x++)
    	{
    		//Print the current number in the sequence
    		System.out.println(vCurrent);
    		//Calculate the new values of the variables
    		vPrevious = vCurrent;
    		vCurrent = vNext;
    		vNext = vPrevious + vCurrent;
		}
    }
}
