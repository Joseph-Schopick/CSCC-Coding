#FILE:      2252_Schopick_Lesson1_Group_Part_1.py
#NAME:      Store Sales Calculator
#AUTHOR:    Joseph Schopick
#DATE:      9/5/2018
#PURPOSE:   Displays the subtotal of the sale, the total amount of tax, and the total amount to be paid, based on user input

#Print the program's name
print("""======================================
\tStore Sales Calculator
======================================""")

#sales tax
vSALES_TAX = 0.055

#ask for the price of the first item
vFirst_Item = float(input("\n\nWhat is the price of the first item? "))

#ask for the price of the second item
vSecond_Item = float(input("\nWhat is the price of the second item? "))

#ask for the price of the third item
vThird_Item = float(input("\nWhat is the price of the third item? "))

#Calculate and display the subtotal of the sale
vSubtotal = round(vFirst_Item + vSecond_Item + vThird_Item,2)
print("\n\nThe subtotal is\t\t$",vSubtotal)

#Calculate and display the total amount of tax to be collected
vTotal_Tax = round(vSubtotal * vSALES_TAX,2)
print("\nThe total tax is\t$",vTotal_Tax)

#Calculate and display the total amount the customer must pay
vTotal_Balance = round(vSubtotal + vTotal_Tax,2)
print("\nThe total amount is\t$",vTotal_Balance)

#Keep from closing
input("\n\nPress Enter to Close")
