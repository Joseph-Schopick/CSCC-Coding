#FILE:      2252_Schopick_Lesson1_Group_Part_2.py
#NAME:      Restaurant Bill Calculator
#AUTHOR:    Joseph Schopick
#DATE:      9/5/2018
#PURPOSE:   Displays the subtotal of the sale, the total amount of tax, and the total amount to be paid, based on user input

#Print the program's name
print("""==========================================
\tRestaurant Bill Calculator
==========================================""")

#Declare variables for tax and tip
vTAX_RATE = 0.065
vTIP_RATE = 0.18

#ask for the total cost of food and drink
vSubtotal = float(input("\n\nWhat is the total cost of food and drink? "))

#Display the subtotal
print("\n\nThe subtotal of the order is\t\t$",vSubtotal)

#Display the total amount of the tip
vTotal_Tip = round(vSubtotal * vTIP_RATE,2)
print("\nThe total amount of the tip is\t\t$",vTotal_Tip)

#Display the total amount of the tax
vTotal_Tax = round(vSubtotal * vTAX_RATE,2)
print("\nThe total amount of the tax is\t\t$",vTotal_Tax)

#Display the total amount of the bill
vTotal_Balance = round(vSubtotal + vTotal_Tip + vTotal_Tax,2)
print("\nThe total amount of the bill is\t\t$",vTotal_Balance)

#Keep from closing
input("\n\nPress Enter to Close")
