#FILE:      2252_Schopick_Paudel_Huddleston_Adhikari_Lesson2_Group_Part_1.py
#NAME:      Apple Cider Converter
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Matthew Huddleston, Mahi Adhikari
#DATE:      9/19/2018
#PURPOSE:   Convert the entered amount of cider from ounces into gills and drams

#print the program's name
print("""====================================
\tApple Cider Converter
====================================""")

#ask user how many ounces of apple cider they want to purchase
vOunces = float(input("\n\n\nPlease enter the amount of apple cider you wish to \
purchase in ounces. "))

#Make sure that the number isn't negative
while vOunces < 0:
    print("\n\n\nYou cannot buy a negative amount of apple cider.")
    vOunces = float(input("\nPlease enter the amount of apple cider you wish to \
purchase in ounces. "))

#calculate and display the number of gills
vGills = round(vOunces/4,2)
print("\n\n\nThe amount of apple cider you want is",vGills,"gills")

#calculate and display the number of drams
vDrams = round(vOunces*8,2)
print("\nThe amount of apple cider you want is",vDrams,"drams")

#If more than 1024 drams, display message indicating that the amount they want
#   is large and they will need to purchase their cider in gallons.
if vDrams > 1024:
    print("\n\n\nThe amount of apple cider that you want is very \
large. \nYou will need to purchase apple cider in gallons.")

#If less than 100 drams, display message indicating that the amount they want
#   is too small and perhaps they should just order a pint.
if vDrams < 100:
    print("\n\n\nThe amount of apple cider that you want is very \
small. \nPerhaps you should just order a pint.")



#keep from closing
input("\n\n\n\n\nPress Enter to Close")
