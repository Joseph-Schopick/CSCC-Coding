#FILE:      2252_Schopick_Paudel_Huddleston_Adhikari_Lesson2_Group_Part_2.py
#NAME:      Color Mixer
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Matthew Huddleston, Mahi Adhikari
#DATE:      9/19/2018
#PURPOSE:   Mix primary colors together and output the resulting color

#print the program's name
print("""====================================
\t    Color Mixer
====================================""")

#ask user for the first color and convert to lowercase
vColor1 = input("\n\n\nPlease enter the first color. ")
vColor1 = vColor1.lower()

#make sure that the first color is "red", "blue", or "yellow"
while not ((vColor1 == "red") or (vColor1 == "blue") or (vColor1 == "yellow")):
    print("\n\n\nERROR: You must enter a primary color.")
    vColor1 = input("\nPlease enter the first color. ")
    vColor1 = vColor1.lower()
    
#ask user for the second color and convert to lowercase
vColor2 = input("\n\n\nPlease enter the second color. ")
vColor2 = vColor2.lower()

#make sure that the second color is "red", "blue", or "yellow"
while not ((vColor2 == "red") or (vColor2 == "blue") or (vColor2 == "yellow")):
    print("\n\n\nERROR: You must enter a primary color.")
    vColor2 = input("\nPlease enter the second color. ")
    vColor2 = vColor2.lower()

#make sure that the colors are different
#if the colors are different then mix them and output the resulting color
if vColor1 == vColor2:
    print("\n\n\nERROR: The colors cannot be the same.")
else:
    if vColor1 == "red":
        if vColor2 == "blue":
            print("\n\n\nThe resulting secondary color is purple.")
        else:
            print("\n\n\nThe resulting secondary color is orange.")
    elif vColor1 == "blue":
        if vColor2 == "yellow":
            print("\n\n\nThe resulting secondary color is green.")
        else:
            print("\n\n\nThe resulting secondary color is purple.")
    else:
        if vColor2 == "red":
            print("\n\n\nThe resulting secondary color is orange.")
        else:
            print("\n\n\nThe resulting secondary color is green.")

#keep from closing
input("\n\n\n\n\nPress Enter to Close.")
