#FILE:      2252_Schopick_Paudel_Huddleston_Davletov_Lesson3_Group_Part_1.py
#NAME:      Brutus Distance Calculator
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Matthew Huddleston, Kudrat Davletov
#DATE:      10/3/2018
#PURPOSE:   This program tracks the distance that a dog ran given the time and speed

#print the program's name
print("""==========================================
\tBrutus Distance Calculator
==========================================""")

#input the number of hours the dog played
vTime = int(input("\nHow many hours did Brutus play fetch? "))

#input the speed of the dog
vSpeed = int(input("\nHow fast did Brutus run in kilometers per hour? "))

#uses a loop to calculate and display the distance the dog ran for each hour.
print("""\n\n\n==========================================
Hour\tBrutus Distance
==========================================\n""")
for vHour in range(1,vTime+1):
    vDistance = vSpeed * vHour
    print(vHour,"\t",vDistance," km\n",sep="")

#keep from closing
input("\n\n\n\nPress Enter to Close")
