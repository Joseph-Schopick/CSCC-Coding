#FILE:      2252_Schopick_Paudel_Huddleston_Davletov_Lesson3_Group_Part_2.py
#NAME:      Shape Maker
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Matthew Huddleston, Kudrat Davletov
#DATE:      10/3/2018
#PURPOSE:   This program creates a shape using nested loops

#print the program's name
print("""===========================
\tShape Maker
===========================\n\n\n""")

#use nested loops to draw the shape 
for x in range(1):
    print("#")
    for n in range(0,4):
        print("#"," "*n,"#",sep="")
    for n in range(4,-1,-1):
        print("#"," "*n,"#",sep="")
    print("#")

#keep from closing
input("\n\n\nPress Enter to Close")
