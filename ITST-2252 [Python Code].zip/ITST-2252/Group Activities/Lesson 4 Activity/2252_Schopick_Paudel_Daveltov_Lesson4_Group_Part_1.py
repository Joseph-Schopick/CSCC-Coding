#FILE:      2252_Schopick_Paudel_Daveltov_Lesson4_Group_Part_1.py
#NAME:      Digital Dice
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Kudrat Davletov
#DATE:      10/17/2018
#PURPOSE:   This program simulates rolling dice

#import random
import random

#create the main function
def main():
    #display program name
    print("""========================================
\t      Digital Dice
========================================""")
    #call roll function
    roll()
    #keep the program from closing
    input("\n\n\nPress Enter to Close")
    
#create the die function
def roll():
    #get number using randint
    vNumber = random.randint(1,6)
    #display number rolled
    print("\n\nThe number you rolled is ",vNumber)
    #call again function
    again()

#create the again function
def again():
    #ask if the user wants to roll again
    vAgain = input("\nDo you want to roll again? (Enter Y/N) ").lower()
    #roll again if the user wants to
    if vAgain == "y":
        #call the roll function
        roll()
    else:
        #return
        return

#call main function
main()
