#FILE:      2252_Schopick_Paudel_Daveltov_Lesson4_Group_Part_2.py
#NAME:      Easy Math Quiz
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Kudrat Davletov
#DATE:      10/17/2018
#PURPOSE:   This program gives an easy math quiz

#import random
import random

#create the main function
def main():
    #display program name
    print("""========================================
\t     Easy Math Quiz
========================================""")
    #call problem function
    problem()
    #keep from closing
    input("\n\n\nPress Enter to Close")

#create problem function
def problem():
    #create numbers and calculate the answer
    vNum_1 = random.randint(1,999)
    vNum_2 = random.randint(1,999)
    vAnswer = vNum_1 + vNum_2
    #display the problem
    print("\n\n\n",vNum_1,"\n+ ",vNum_2,"\n-----",sep="")
    #take the user's answer
    vUser_Answer = int(input())
    #check the user's answer against the actual answer and display correct result
    if vUser_Answer == vAnswer:
        print("\nCongratulations that is the correct answer!")
    else:
        print("\nThat was not the answer! The correct answer is ",vAnswer,"! Go back to school!",sep="")
    #call again function
    again()

#create the again function
def again():
    #ask if the user wants to answer another problem
    vAgain = input("\nDo you want to answer another problem? (Enter Y/N) ").lower()
    #ask another problem if the user wants to
    if vAgain == "y":
        #call the problem function
        problem()
    else:
        #return
        return


#call main function
main()
