#FILE:      2252_Schopick_Paudel_Davletov_Bowling_Mohamud_Tall_Lesson5_Group.py
#NAME:      English to Pirate Translator
#AUTHOR:    Schopick, Paudel, Davletov, Bowling, Mohamud, Tall
#DATE:      11/7/2018
#PURPOSE:   This program translates an english phrase into pirate speak

#import random
import random

#define the main function
def main():
    #display program name
    print("""================================================
\tEnglish to Pirate Translator
================================================""")
    #declare variable to continue to translate
    translate = 'y'
    #if the user wants to continue to translate run the program again
    while translate == 'y':
        #call english function
        english()
        #ask if the user wants to translate something else
        translate = input("\n\nDo you want to translate anything else? [Enter y/n] ").lower()
    #keep the program from closing
    input("\n\n\nPress Enter to Quit")
    
#define the english function
def english():
    #define english and pirate word lists
    lEnglish = ['hello','hi','my','friend','sir','where','is','there','the','you','ing']
    lPirate = ['ahoy','yo-ho-ho','me','bucko','matey','whar','be',"thar","th'","ye","in'"]
    #get phrase from user
    vPhrase = input("\n\nPlease enter a phrase using the following words:\n[hello,hi,my,friend,sir,where,is,the,there,you,ing]\n").lower()
    #find words loop
    for vNumber in lEnglish:
        #call arr function
        vArr = arr()
        #if arr was True insert arr
        if vArr == True:
            #translate using replace
            vPhrase = vPhrase.replace(vNumber,"arr "+lPirate[lEnglish.index(vNumber)])
        #otherwise don't insert arr
        else:
            #translate using replace
            vPhrase = vPhrase.replace(vNumber,lPirate[lEnglish.index(vNumber)])
    #display translated phrase
    print("\nThe phrase translated into pirate is:",vPhrase.capitalize())

#define the arr function
def arr():
    #make a variable for the random value
    vRandom = random.randint(1,2)
    #if randint is 4
    if vRandom == 2:
        #return True
        return True
    #otherwise
    else:
        #return False
        return False

#keep the main funtion from running automatically if imported
if __name__ == "__main__":
    main()
