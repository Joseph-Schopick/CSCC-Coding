#FILE:      2252_Schopick_Paudel_Davletov_Adhikari_Lesson6_Group.py
#NAME:      Random Integer Generator
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Kudrat Davletov, Mahi Adhikari
#DATE:      11/14/2018
#PURPOSE:   Prompts user for an integer and generates that many random numbers

#import random
import random

#define the main function
def main():
    #display program name
    print("""================================================
\tRandom Integer Generator
================================================""")
    #while the user wants to continue generating random numbers
    vContinue = 'y'
    while vContinue == 'y':
        #call generate function
        generate()
        #ask if the user wants to generate more random numbers
        vContinue = input("\n\n\nDo you want to generate more random numbers? [Enter Y/N] ").lower()
    #keep the program from closing
    input("\n\n\n\n\nPress Enter to Close")
    
#define the generate function
def generate():
    #define empty list for random integers
    lIntegers = list()
    #get number of integers from the user
    try:
        vNumber = int(input("\n\nPlease enter the number of random integers you would like to generate: "))
    except:
        print("\n\n\nERROR: You must enter an integer.")
        generate()
    else:
        #if the entered integer is less than or equal to zero output error message
        if vNumber <= 1:
            print("\n\n\nERROR: You must enter an integer that is more than zero.")
            generate()
        #use a loop to fill the list with the user's number of random integers
        for x in range(1,vNumber+1):
            lIntegers.append(random.randint(1,500))
        #call display function
        display(lIntegers,vNumber)

#define the display(the_list) function
def display(lList,vNum):
    #display the list of integers
    print("\n\n\nThe list of integers is:",lList)
    #display the lowest number in the list
    print("\nThe lowest number in the list is:",min(lList))
    #display the highest number in the list
    print("\nThe highest number in the list is:",max(lList))
    #display the total sum of all the numbers in the list
    print("\nThe total sum of all the numbers in the list is:",sum(lList))
    #display the average number in the list
    print("\nThe average number in the list is:",(sum(lList)/vNum))

#keep the main funtion from running automatically if imported
#if __name__ == "__main__":
main()
