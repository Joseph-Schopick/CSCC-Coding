#FILE:      2252_Schopick_Paudel_Davltov_Lesson7_Group.py
#NAME:      Random Integer Generator
#AUTHOR:    Joseph Schopick, Yadhap Paudel, Kudrat Davltov
#DATE:      12/5/2018
#PURPOSE:   Prompts user for an integer and generates that many random numbers

#import random
import random

#define the main function
def main():
    #display the program name
    print("""================================================
\tRandom Integer Generator
================================================""")
    #while the user wants to continue generating random numbers
    vContinue = 'y'
    while vContinue == 'y':
        #call generate function
        generate()
        #ask if the user wants to generate more random numbers
        vContinue = input("\n\n\nDo you want to generate more random numbers? [Enter Y/N] ").lower()
    #keep the program from closing
    input("\n\n\n\n\nPress Enter to Close")
    
#define the generate function
def generate():
    #get number of integers from the user
    #try/except for non-integers error message
    try:
        vNumbers = int(input("Please enter the number of random integers that you want to generate: "))
    except:
        print("ERROR: Please enter an integer")
        generate()
    #else
    else:
        #if for > 0 integers
        if vNumbers > 0:
            #create or open file in write mode
            fin = open('RandomIntegers.txt','w')
            #generate random integers with for loop
            for x in range(0,vNumbers):
                vRandInt = random.randrange(50,500)
                #turn the integers into strings?
                vRandInt = str(vRandInt)
                #store in file
                fin.write(vRandInt+'\n')
            #close file
            fin.close()
            #call display function
            display()
        #else error message
        else:
            print("ERROR: Please enter an integer above 0")
            generate()

#define the display function
def display():
    #create an empty list to store the integers
    lIntegers = list()
    #open file in read mode
    fin = open('RandomIntegers.txt','r')
    #use a for loop to put the random integers into the list
    for line in fin:
        #turn the strings back into integers
        vRandInt = int(line)
        #store them in the list
        lIntegers.append(vRandInt)
    #display the list of integers
    print("The list of integers is:",lIntegers)
    #display the lowest number in the list
    print("\nThe lowest number in the list is:",min(lIntegers))
    #display the highest number in the list
    print("\nThe highest number in the list is:",max(lIntegers))
    #display the total sum of all the numbers in the list
    print("\nThe total sum of all the numbers in the list is:",sum(lIntegers))
    #display the average number in the list
    print("\nThe average number in the list is:",(sum(lIntegers)/len(lIntegers)))
    #close file
    fin.close()

#keep the main funtion from running automatically if imported
if __name__ == "__main__":
    main()
