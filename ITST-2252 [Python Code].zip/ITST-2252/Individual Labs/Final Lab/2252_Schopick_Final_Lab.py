#FILE:      2252_Schopick_Final_Lab.py      The submission confirmation number is e24384ae-a1e0-421c-8bf5-e8447e2df788.
#NAME:      WarGames Trivia Game
#AUTHOR:    Joseph Schopick
#DATE:      12/8/2018
#PURPOSE:   This program quizes the user on trivia related to the 1983 movie WarGames


#define the main function
def main():
    #display the name of the program
    print("""========================================
\t  WarGames Trivia Game
========================================
A trivia game on the 1983 movie WarGames - Coded by Joseph Schopick
Questions originally from funtrivia.com Quizzes #95,281 and #295,162
========================================

Rules - Answers are Not Case Sensitive but All Punctuation Must Be Included.""")
    #make a variable so that the user can choose to play multiple times
    vContinue = 'y'
    #use while loop to call the questions function
    while vContinue == 'y':
        #call questions function
        questions()
        #ask the user if they want to play again
        try:
            vContinue = input("\n\n\n\nShall we play the trivia game again? [Enter Y/N] ").lower()
        except:
            vContinue = 'n'
    #display exit message and keep from closing
    input("""\n\n\n\n\n========================================
\t Thank You For Playing
      Please Press Enter to Close
========================================""")

#define the questions function
def questions():
    #create a dictionary with the question numbers as the keys and the questions, possible answers, and the correct answers as values
    dQuestions = {'In the opening scene, we see a couple of Air Force Officers receiving a message. Under what capacity do these officers work?':['The officers are computer programmers','They are navigators','They are pilots','They are missile launch officers','They are missile launch officers'],'We learn early in the film that several "false alarms" were sprung upon military personnel all across the country. What percentage of missile commanders failed to approve the ordered launch?':['32%','22%','28%','38%','22%'],'Dr. John McKittrick believes that the defense system should be improved. What is his suggestion?':['Human personnel should be replaced with computer relays from WOPR','Better missiles should be built','Personnel should be more thoroughly examined for psychological deficiencies','He has no clue','Human personnel should be replaced with computer relays from WOPR'],'In which U.S. city does David Lightman (Matthew Broderick) live? ':['New York','Chicago','Boston','Seattle','Seattle'],'David arrives late for biology class. The biology teacher poses the question: "Who first suggested the idea of reproduction without sex?" What is David\'s reply?':['"Female sharks"','"Einstein"','"Herschfeld"','"Your wife?"','"Your wife?"'],'David finds a site, which lists a number of games available. Which of the following games are on the list?':['chess','all of these','checkers','bridge','all of these'],'David visits a computer development company, where he has some friends. Malvin suggests that they will never get in. Jim says that there might be a \'back door\', much to Malvin\'s chagrin. Malvin has a fit. Jim chastises Malvin and calls him a name. What does he call Malvin?':['"Silly Goose"','"Mr. Potato Head"','"Broomstick"','"Dweebster"','"Mr. Potato Head"'],'David stumbles upon his first clue to the mystery before him because the programmer he is investigating has included his name in the title of a game. What is the name of the game?':['Falken\'s Riddle','Falken\'s Maze','Falken\'s War','Falken\'s Challenge','Falken\'s Maze'],'What is the address of David Lightman\'s house?':['111','222','333','444','333'],'According to David\'s research, how old was Stephen Falken when he allegedly died?':['39','45','43','41','41'],'David discovers the password, gaining access to the WOPR account. The computer asks David if he would like to play a game. What game does David prefer to play?':['Hearts','Chess','Global Thermonuclear War','Fighter Combat','Global Thermonuclear War'],'What game does David enlist the computer to play in order to prevent it from completing the game of Global Thermonuclear War?':['Chess','Bridge','Checkers','Tic-Tac-Toe','Tic-Tac-Toe']}
    #create a list of questions so that questions can be asked more easily
    lQuestions = list(dQuestions.items())
    #create a file to store the questions
    fin = open('TriviaQuestions.txt','w')
    #use a for loop to ask all of the questions
    for Q in lQuestions:
        #write the full question to the file
        fin.write(Q[0]+"\n")        #Question
        fin.write(Q[1][0]+"\n")
        fin.write(Q[1][1]+"\n")
        fin.write(Q[1][2]+"\n")
        fin.write(Q[1][3]+"\n")
        fin.write(Q[1][4]+"\n")     #Correct Answer
    #close file
    fin.close()
    #call the quiz function
    quiz()

#define the quiz function
def quiz():
    #create a counter for the player's correct answers
    vPlayerScore = 0
    #open the question file in read mode
    fout = open('TriviaQuestions.txt','r')
    #make a for loop to count the number of lines in the file
    vLineCount = 0
    for lines in fout:
        vLineCount += 1
    #create a variable for the number of questions
    vQuestionCount = int(vLineCount/6)
    #close the file
    fout.close()
    #open the question file again in read mode
    fin = open('TriviaQuestions.txt','r')
    #make a for loop to ask all of the questions
    for q in range(1,vQuestionCount+1):
        #print question number
        print("\n\n\n\nQuestion",q,"of",vQuestionCount,"\n")
        #make a while loop to ask the whole question
        vCount = 0
        while vCount < 5:
            print(fin.readline().strip(),"\n")
            vCount += 1
        #get the correct answer from the file
        vAnswer = fin.readline().strip()
        #get player input
        vPlayerAnswer = input("Please enter your answer here: ").lower()
        #check player's answer
        if vPlayerAnswer == vAnswer.lower():
            #if answer is correct add to counter
            vPlayerScore += 1
            #tell the player that their answer was correct and their score
            print("\nCorrect!!!\n\nYour score is:",vPlayerScore)
        else:
            #tell the player the correct answer
            print("\nThe correct answer is:",vAnswer)
            #tell the player their score
            print("\nYour score is:",vPlayerScore)
    #output the player's final score
    print("\n\nYour final score is:",vPlayerScore,"out of",vQuestionCount)
    #close the file
    fin.close()

if __name__ == "__main__":
    main()
