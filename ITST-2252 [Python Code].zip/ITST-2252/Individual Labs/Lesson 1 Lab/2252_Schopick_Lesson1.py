#FILE:      2252_Schopick_Lesson1.py
#NAME:      Brownie Recipe Calculator
#AUTHOR:    Joseph Schopick
#DATE:      9/7/2018
#PURPOSE:   Calculates the correct recipe for baking brownies based on how many the user inputs that they want to bake

#Print the program's name
print("""=========================================
\tBrownie Recipe Calculator
=========================================""")

#Declare variables for all the ingredients
#Measurements for 9 brownies divided by 9 to get the measurement per 1 brownie
vBUTTER = 0.5/9            #Cups
vEGGS = 2.0/9              #Whole Eggs
vVANILLA = 1.0/9           #Teaspoons
vSUGAR = 1.0/9             #Cups
vFLOUR = 0.5/9             #Cups
vCOCOA_POWDER = 0.5/9      #Cups
vBAKING_POWDER = 0.25/9    #Teaspoons
vSALT = 0.25/9             #Teaspoons

#Ask for the number of brownies the user wants to bake
vBrownies = float(input("\n\nPlease enter the number of brownies that you wish to bake. "))

#Display the recipe needed for the number of brownies the user wants to bake
print("""\n\n\n\n\n=========================================
\t  Python Brownie Recipe
=========================================""")
print("\n\nTo make",vBrownies,"brownies you will need the following ingredients:\n")
print(round(vBUTTER*vBrownies,2),"\tcups butter")
print(round(vEGGS*vBrownies,2),"\teggs")
print(round(vVANILLA*vBrownies,2),"\tteaspoons vanilla")
print(round(vSUGAR*vBrownies,2),"\tcups sugar")
print(round(vFLOUR*vBrownies,2),"\tcups flour")
print(round(vCOCOA_POWDER*vBrownies,2),"\tcups cocoa powder")
print(round(vBAKING_POWDER*vBrownies,2),"\tteaspoons baking powder")
print(round(vSALT*vBrownies,2),"\tteaspoons salt")

#Keep from closing
input("\n\n\nPress Enter to Close")
