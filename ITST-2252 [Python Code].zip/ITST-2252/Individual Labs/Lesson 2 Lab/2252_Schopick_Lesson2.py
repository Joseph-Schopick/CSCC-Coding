#FILE:      2252_Schopick_Lesson2.py
#NAME:      Python Rocks Ticket Price Calculator
#AUTHOR:    Joseph Schopick
#DATE:      9/17/2018
#PURPOSE:   Calculates the tier and ticket price based on a guest's height

#Print the program's name
print("""============================================
    Python Rocks Ticket Price Calculator
============================================""")

#Ask for the height of the guest
vHeight = float(input("\n\nPlease enter the height of the guest in inches. "))

#Calculate and display the name of the tier and the cost of the ticket
print("""\n\n\n\n\n============================================
\t    Python Rocks Ticket
============================================""")
if vHeight < 30:
    print("\n\nA guest who is",vHeight,"inches tall is in the Guppy Tier.")
    print("\nGuppy Tier tickets are Free!")
elif vHeight < 36:
    print("\n\nA guest who is",vHeight,"inches tall is in the Pollywog Tier.")
    print("\nPollywog Tier tickets cost $2 each.")
elif vHeight < 42:
    print("\n\nA guest who is",vHeight,"inches tall is in the Apprentice Tier.")
    print("\nApprentice Tier tickets cost $5 each.")
elif vHeight < 48:
    print("\n\nA guest who is",vHeight,"inches tall is in the Explorer Tier.")
    print("\nExplorer Tier tickets cost $8 each.")
else:
    print("\n\nA guest who is",vHeight,"inches tall is in the Adventurer Tier.")
    print("\nAdventurer Tier tickets cost $10 each.")

#Keep from closing
input("\n\n\n\n\nPress Enter to Close")
