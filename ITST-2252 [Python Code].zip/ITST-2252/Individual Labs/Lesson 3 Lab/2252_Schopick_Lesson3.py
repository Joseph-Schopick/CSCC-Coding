#FILE:      2252_Schopick_Lesson3.py
#NAME:      Chess Board Maker
#AUTHOR:    Joseph Schopick
#DATE:      9/23/2018
#PURPOSE:   This program creates a chess board using nested loops.

#print the program's name
print("""==========================================
\t    Chess Board Maker
==========================================\n\n\n""")

#create chess board
for vRow in range(8,0,-1):
    print("------------------------------------------")
    for vColumn in ['a','b','c','d','e','f','g','h']:
        print("| ",vColumn,vRow,sep="",end=" ")
    else:
        print("|")           
else:
    print("------------------------------------------")

#keep from closeing
input("\n\n\nPress Enter to Close")
