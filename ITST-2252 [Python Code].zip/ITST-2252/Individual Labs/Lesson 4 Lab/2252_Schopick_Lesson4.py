#FILE:      2252_Schopick_Lesson4.py
#NAME:      Rock, Paper, Scissors
#AUTHOR:    Joseph Schopick
#DATE:      10/20/2018
#PURPOSE:   This program plays rock, paper, scissors with the user

#import random
import random
#create variables for scores and rounds
vUser_Score = 0
vComp_Score = 0
vRounds = 0
    
#define a main function
def main():
    #print the program's name
    print("""==================================================================
\t\t      Rock, Paper, Scissors
==================================================================\n\n\n""")
    #get the user's name
    global vName
    vName = input("What is your name user? ")
    #see if the user wants to play
    vPlay = input("\nShall we play a game? (of rock, paper, scissors)\
    Enter Y/N: ").lower()
    #while the user wants to play, on their own head be it
    while vPlay == "y":
        #call the rps function
        vPlay = rps()
    else:
        #determine the overall winner
        if vComp_Score > vUser_Score:
            vWinner = "The Computer Wins!!! Better luck next time meatbag."
        elif vUser_Score > vComp_Score:
            vWinner = "You Win "+vName+"!!! Stick to tic-tac-toe WOPR."
        else:
            vWinner = "The Game is a Tie!"
        #print the total rounds and scores
        print("\n\n\n\n==================================================================")
        print("Total Rounds", vRounds, "  ", vName, "Has", vUser_Score, "Points    \
The Computer Has", vComp_Score, "Points")
        print(vWinner)
        print("==================================================================\n")
        #keep from closeing
        input("\n\n\nPress Enter to Close")

#define rps function
def rps():
    #make it so that rps can use variables for scores rounds and name
    global vUser_Score,vComp_Score,vRounds,vName
    #call the choose function and return the computer and user choices
    vComp_Choice,vUser_Choice = choose()
    #if the computer and user choices are the same call choose until the aren't
    while vComp_Choice == vUser_Choice:
        print("Tie! Try again.")
        vComp_Choice,vUser_Choice = choose()
    #determine the winner and count the winner's score
    if ((vUser_Choice=="rock" and vComp_Choice=="scissors") or (vUser_Choice=="scissors" and vComp_Choice=="paper") or (vUser_Choice=="paper" and vComp_Choice=="rock")):
        print(vName, "Wins This Round!")
        vUser_Score += 1
    else:
        print("The Computer Wins This Round!")
        vComp_Score += 1
    #count the rounds
    vRounds += 1
    #print the round and scores
    print("""\n==================================================================
Round""", vRounds, '  ', vName, 'Has', vUser_Score, 'Points    \
The Computer Has', vComp_Score, """Points
==================================================================""")
    #see if the user wants to play again and return this choice to main
    vContinue = input("\nShall we play this game again?    Enter Y/N: ").lower()
    return vContinue

#define choose function
def choose():
    #generate the computer's choice using random
    vComp_Choice = random.randint(1,3)
    #set the computer's choice to "rock", "paper", or "scissors"
    if vComp_Choice == 1:
        vComp_Choice = "rock"
    elif vComp_Choice == 2:
        vComp_Choice = "paper"
    else:
        vComp_Choice = "scissors"
    #get the user's choice
    vUser_Choice = input("\n\n\n\nWhat'll it be? Rock, Paper, or Scissors? ").lower()
    #make sure that the user chose "rock", "paper", or "scissors"
    while not ((vUser_Choice == "rock") or (vUser_Choice == "paper") or (vUser_Choice == "scissors")):
        vUser_Choice = input("\nYou can only play Rock, Paper, or Scissors. \
Choose again please. ").lower()
    #print the computer's choice
    print("\nThe computer has chosen",vComp_Choice,end="\n\n")
    #return the choices to rps
    return vComp_Choice,vUser_Choice

#keep main function from being called automatically if imported
if __name__ == "__main__":
    main()
