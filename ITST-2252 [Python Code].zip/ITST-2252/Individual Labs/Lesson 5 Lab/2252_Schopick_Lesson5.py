#FILE:      2252_Schopick_Lesson5.py
#NAME:      Encoder/Decoder
#AUTHOR:    Joseph Schopick
#DATE:      10/29/2018
#PURPOSE:   This program encodes or decodes a series of letters or numbers

#define a main function
def main():
    #print the program's name
    print("""==================================================================
\t\t\tEncoder/Decoder
==================================================================\n\n\n""")
    #call encryption function
    encryption()
    #keep from closing
    input("""\n\n\n\n\n==================================================================
\t Thank You For Using The Encoder/Decoder Program
\t\t\tPress Enter To Close
==================================================================""")

#define encryption function
def encryption():
    #define variable so that user can choose to encode or decode something else
    vUseAgain = "y"
    #while the user wants to use the program
    while vUseAgain == "y":
        #menu for user to choose to encode or decode
        vChoice = input("\n\n[Enter (E/e) to Encode] [Enter (D/d) to Decode] ").lower()
        #if encode
        if vChoice == "e":
            #call encode function
            encode()
            #ask if the user wants to use the program again
            vUseAgain = input("\n\n\nDo you want to encode or decode something else? [Enter (Y/N)] ").lower()
        #else if decode
        elif vChoice == "d":
            #call decode function
            decode()
            #ask if the user wants to use the program again
            vUseAgain = input("\n\n\nDo you want to encode or decode something else? [Enter (Y/N)] ").lower()
        #else (if neither encode nor decode is entered)
        else:
            #output that the user failed to choose
            print("\nYou didn't choose to encode or decode correctly. Try again.\n\n")
            #call encryption function again
            encryption()
            vUseAgain = "n"

#define encode function
def encode():
    #explain how to encode
    print("\nThe program encodes letters into numbers. A=1, B=2, C=3, etc.")
    print("Please use proper punctuation and capitalization.")
    #ask for string to encode
    vToEncode = input("\n\n\nPlease enter the string to be encoded: ").lower()
    #use try to test if vToEncode isn't empty or some other error
    try:
        vToEncode[0].isalpha()
    #use except if it isn't
    except:
        #output that something went wrong
        print("\nSomething went wrong. To encode you must enter letters. Please try again.\n")
        #call encryption function again
        encryption()
    #use else if vToEncode isn't empty
    else:
        #if index 0 is a letter
        if vToEncode[0].isalpha():
            #declare a variable for the encoded string
            vEncoded = ""
            #use a for loop to turn letters into numbers separated by dashes
            for char in vToEncode:
                #if the character is a letter
                if char.isalpha():
                    vNewChar = cypher(char)
                    vEncoded = vEncoded + vNewChar + "-"
                #if the character is anything else
                else:
                    vEncoded = vEncoded[:len(vEncoded)-1] + char
            #display both strings
            print('\n\n"',vToEncode.capitalize(),'" would encode as "',vEncoded,'"',sep="")
        #else
        else:
            #output that to encode you input letters and this string didn't
            print("\nTo encode you must enter letters.\n")
            #ask if the user maybe meant to decode instead
            print("Perhaps you meant to decode instead. Please try again.\n")
            #call encryption function again
            encryption()

#define decode function
def decode():
    #explain how to decode
    print("\nThe program decodes numbers separated by dashes back into letters.")
    print("1=A, 2=B, 3=C, etc. Please use proper punctuation.")
    #ask for string to decode
    vToDecode = input("\n\n\nPlease enter the string to be decoded: ")
    #use try to test if index 0 is a number
    try:
        int(vToDecode[0])
    #use except if index 0 isn't a number
    except (NameError, ValueError, TypeError):
        #output that to decode you start numbers and this string didn't
        print("\nTo decode you must enter numbers.\n")
        #ask if the user maybe meant to encode instead
        print("Perhaps you meant to encode instead. Please try again.\n")
        #call encryption function again
        encryption()
    #use except to catch any other errors like empty strings
    except:
        #output that something went wrong or was entered incorrectly
        print("\nSomething went wrong or was entered incorrectly.\n")
        #call encryption function again
        encryption()
    #use else if index 0 is a number
    else:
        str(vToDecode[0])
        #if index 0 is 0
        if vToDecode[0] == "0":
            #output that you can't decode a string starting with 0
            print("\nYou can't decode a string if it starts with zero.\n")
            #call encryption function again
            encryption()
        #else
        else:
            #call cypher function
            vDecoded = cypher(vToDecode)
            #if the character is a dash eliminate it
            vDecoded = vDecoded.replace("-","")
            #display both strings
            print('\n\n"',vToDecode,'" would decode as "',vDecoded.capitalize(),'"',sep="")

#define cypher function to change letters into numbers and vice versa using two arrays of equal length
def cypher(char):
    vCypherAlpha = ["j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z","a","b","c","d","e","f","g","h","i"]
    vCypherNum = ["10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","1","2","3","4","5","6","7","8","9"]
    #turn letters into numbers
    if char.isalpha():
        vCount = 0
        for vLetter in vCypherAlpha:
            if char == vLetter:
                char = vCypherNum[vCount]
            vCount += 1
    #turn numbers into letters
    else:
        #use a for loop to turn numbers into letters
        for vNumber in vCypherNum:
            char = char.replace(vNumber,vCypherAlpha[vCypherNum.index(vNumber)])
    return char
    
#keep main function from being called automatically if imported
if __name__ == "__main__":
    main()
