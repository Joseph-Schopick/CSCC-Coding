#FILE:      2252_Schopick_Lesson6.py
#NAME:      U.S. States Quiz
#AUTHOR:    Joseph Schopick
#DATE:      11/14/2018
#PURPOSE:   This program randomly quizes the user on the names of the state

#import random
import random

#define a main function
def main():
    #print the program's name
    print("""==================================================================
\t\t\tU.S. States Quiz
==================================================================""")
    #make a variable so that the user can choose to play multiple times
    vQuiz = "y"
    #while the user wants to quiz themself let them
    while vQuiz == "y":
        #call quiz function
        quiz()
        #ask if the user wants to quiz themself again
        vQuiz = input("\n\n\nWould you like to take the U.S. States Quiz again? [Enter Y/N] ").lower()
    #keep from closing
    input("""\n\n\n\n\n==================================================================
\t Thank You For Using The U.S. States Quiz Program
\t\t\tPress Enter To Close
==================================================================""")

#define quiz function
def quiz():
    #create a dictionary of states names as keys and abbreviations as values
    dStates = {'Alabama':'AL','Alaska':'AK','Arizona':'AZ','Arkansas':'AR','California':'CA','Colorado':'CO','Connecticut':'CT','Delaware':'DE','Florida':'FL','Georgia':'GA','Hawaii':'HI','Idaho':'ID','Illinois':'IL','Indiana':'IN','Iowa':'IA','Kansas':'KS','Kentucky':'KY','Louisiana':'LA','Maine':'ME','Maryland':'MD','Massachusetts':'MA','Michigan':'MI','Minnesota':'MN','Mississippi':'MS','Missouri':'MO','Montana':'MT','Nebraska':'NE','Nevada':'NV','New Hampshire':'NH','New Jersey':'NJ','New Mexico':'NM','New York':'NY','North Carolina':'NC','North Dakota':'ND','Ohio':'OH','Oklahoma':'OK','Oregon':'OR','Pennsylvania':'PA','Rhode Island':'RI','South Carolina':'SC','South Dakota':'SD','Tennessee':'TN','Texas':'TX','Utah':'UT','Vermont':'VT','Virginia':'VA','Washington':'WA','West Virginia':'WV','Wisconsin':'WI','Wyoming':'WY'}
    #create a tuple of states so that questions can be asked more easily
    tStates = list(dStates.items())
    #create dictionaries for correct and incorrect user answers
    dUser_Correct = {'Correct':0}
    dUser_Incorrect = {'Incorrect':0}
    #create an empty list of states missed by the user
    lMissed = []
    #make a variable so that the user can answer multiple questions
    vQuestion = "y"
    #while the user wants to answer questions let them
    while vQuestion == "y":
        #randomly quiz user by displaying the abbreviation and asking for the state's name
        vState = tStates[random.randrange(len(tStates))][0]
        #get the user's answer
        vUser_Answer = input("\n\nWhich U.S. state is represented by " + str(dStates[vState]) + "?  ").lower()
        #test to see if the response is in the dictionary of states
        try:
            test = dStates[vUser_Answer.title()]
        except:
            #count the number of response not in the dictionary
            dUser_Incorrect['Incorrect'] += 1
            print("\nThe correct answer is the state of",vState)
            #add the state that the user missed to a list
            lMissed.append(vState)
        else:
            if dStates[vUser_Answer.title()] == dStates[vState]:
                #count the number of correct user responses
                dUser_Correct['Correct'] += 1
                print("\nCorrect!!!")
            else:
                #count the number of incorrect user responses
                dUser_Incorrect['Incorrect'] += 1
                print("\nThe correct answer is the state of",vState)
                #add the state that the user missed to a list
                lMissed.append(vState)
        vQuestion = input("\n\n\nWould you like to answer another question? [Enter Y/N] ").lower()
    #print the number of questions answered correctly and incorrectly
    print("\n\nThe user answered",dUser_Correct['Correct'],"questions correctly.\nThe user answered",dUser_Incorrect['Incorrect'],"questions incorrectly.\n\nThe user miss the following states and abbreviations:")
    #print the states and abbreviations that the user missed
    for x in lMissed:
        print("State:",x,"\tAbbreviation:",dStates[x])
    
#keep main function from being called automatically if imported
if __name__ == "__main__":
    main()
