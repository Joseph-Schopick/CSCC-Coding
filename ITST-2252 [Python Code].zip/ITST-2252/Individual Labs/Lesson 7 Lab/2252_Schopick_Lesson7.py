#FILE:      2252_Schopick_Lesson7.py
#NAME:      World Series Reference Program
#AUTHOR:    Joseph Schopick
#DATE:      12/3/2018
#PURPOSE:   This program displays the number of times and the years that a team the user enters won the world series


#define the main function
def main():
    #display the name of the program
    print("""========================================
     World Series Reference Program
========================================""")
    #use while loop to call the reference function
    vContinue = 'y'
    while vContinue == 'y':
        reference()
        #ask the user if they want to use the reference function again
        try:
            vContinue = input("\n\n\nDo you want to inquire about a different team? [Enter Y/N] ").lower()
        except:
            vContinue = 'n'
    #display exit message and keep from closing
    input("""\n\n\n\n\n========================================
     Thank You For Using My Program
      Please Press Enter to Close
========================================""")

#define the reference function
def reference():
    #define a variable to count the number of times that a given team won
    vCount = 0
    #define a variable to see if the counter variable has changed
    vCheck = 0
    #create an empty list to store the years that the given team won
    lYears = []
    #try
    try:
        #prompt the user for the team that they want to search for
        vTeamName = input("\n\n\nPlease enter the name of the team that you want to search for: ").title()
    #except
    except:
        #output message and call the reference function
        print("\nThe team name you entered caused an error. Please try again.")
    #else
    else:
        #open 'WorldSeriesWinners.txt' file in read mode
        fin = open('WorldSeriesWinners.txt','r')
        #make a for loop that will go through each line of the .txt file
        for line in fin:
            #if the counter has changed
            if vCheck < vCount:
                #append the list with the line (year that the team won)
                lYears.append(line.strip())
                #make vCheck variable equal to vCount variable
                vCheck = vCount
            #if the line is the same as the team
            if line.strip() == vTeamName:
                #increase the counter
                vCount += 1
        #output the results of the program
        print("\nThe",vTeamName,"won the World Series",vCount,"times.")
        if vCount > 0:
            print("\nThey won in the years:",lYears)
        #close the .txt file
        fin.close()

#Make sure that the program doesn't run automatically if it's imported
if __name__ == "__main__":
    main()
